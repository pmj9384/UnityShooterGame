using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;                  // 이동 속도
    public Camera mainCamera;                 // 카메라 참조
    public Vector3 cameraFixedPosition = new Vector3(0, 10f, -10f);  // 카메라 고정 위치
    public Vector3 cameraRotationEuler = new Vector3(45f, 0f, 0f);  // 카메라 고정 각도 (위에서 내려다보는 시점)

    private Rigidbody rb;
    private Animator animator;                // 애니메이터 추가

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();  // Animator 컴포넌트 가져오기

        Cursor.lockState = CursorLockMode.None;  // 마우스 잠금 해제 (롤 스타일)
        Cursor.visible = true;                   // 마우스 표시

        // **카메라 고정 설정**
        mainCamera.transform.position = cameraFixedPosition;
        mainCamera.transform.rotation = Quaternion.Euler(cameraRotationEuler);
    }

    private void FixedUpdate()
    {
        float horizontal = Input.GetAxis("Horizontal");  // A, D 입력
        float vertical = Input.GetAxis("Vertical");      // W, S 입력

        // **이동 방향 계산 (플레이어의 로컬 방향 기준)**
        Vector3 moveInput = (transform.right * horizontal + transform.forward * vertical).normalized;

        if (moveInput.sqrMagnitude > 0.01f)  // 움직이고 있을 때
        {
            // **이동 처리**
            Vector3 moveDirection = moveInput * speed * Time.deltaTime;
            rb.MovePosition(rb.position + moveDirection);

            // **Walk 애니메이션 활성화**
            animator.SetBool("Walk", true);
        }
        else
        {
            // **Walk 애니메이션 비활성화**
            animator.SetBool("Walk", false);
        }

        // **마우스 위치에 따라 회전**
        RotateTowardsMouse();

        // **카메라 고정 유지**
        LockCamera();
    }

    private void RotateTowardsMouse()
    {
        // **마우스 스크린 위치를 월드 좌표로 변환**
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        Plane groundPlane = new Plane(Vector3.up, Vector3.zero);  // y축 기준 평면

        if (groundPlane.Raycast(ray, out float enter))
        {
            Vector3 mouseWorldPosition = ray.GetPoint(enter);  // 마우스 월드 좌표
            Vector3 direction = (mouseWorldPosition - transform.position).normalized;  // 바라볼 방향
            direction.y = 0f;  // 평면 이동

            if (direction.sqrMagnitude > 0.01f)
            {
                Quaternion targetRotation = Quaternion.LookRotation(direction);
                transform.rotation = targetRotation;  // 플레이어 회전
            }
        }
    }

    private void LockCamera()
    {
        // **카메라 위치 고정**
        mainCamera.transform.position = cameraFixedPosition;
        mainCamera.transform.rotation = Quaternion.Euler(cameraRotationEuler);
    }
}
