using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class UiManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI waveText;
    public GameObject gameOverPanel;

    public void UpdateScoreText(int newScore)
    {
        scoreText.text = $"SCORE: {newScore}";
    }

    public void UpdateWaveText(int wave, int count)
    {
        waveText.text = $"Wave: {wave}\nEnemy Left: {count}";
    }

    public void ShowGameOverPanel(bool active)
    {
        gameOverPanel.SetActive(active);
    }

    public void OnClickReStart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
