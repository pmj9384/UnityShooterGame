using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieSpawner : MonoBehaviour
{
    [SerializeField] private Zombie[] prefabs;  // 여러 종류의 좀비 프리팹 배열
    [SerializeField] private ZombieData[] datas;  // 좀비 데이터 배열 (프리팹에 대응)
    [SerializeField] private Transform[] spawnPoints;  // 스폰 위치 배열
    [SerializeField] private float spawnInterval = 1f;  // 스폰 간격

    private GameManager gm;
    private int wave = 1;  // 현재 웨이브
    private float nextSpawnTime;  // 다음 스폰 시간
    private List<Zombie> zombies = new List<Zombie>();  // 활성화된 좀비 리스트

    private void Start()
    {
        gm = GameObject.FindWithTag("GameController").GetComponent<GameManager>();
    }

    private void Update()
    {
        if (gm.IsGameOver) 
        return;  // 게임 오버 시 스폰 중지

        if (zombies.Count == 0)
        {
            SpawnWave();
        }
    }

    private void SpawnWave()
    {
       ++wave;
        int count = Mathf.RoundToInt(wave * 1.5f);
        for (int i = 0; i < count; ++i)
        {
            CreateZombie();
        }
    }

private void CreateZombie()
{
    var data = datas[Random.Range(0, datas.Length)];
    var spawnPoint = spawnPoints[Random.Range(0, spawnPoints.Length)];

    // **prefabs 배열에서 랜덤 좀비 프리팹 선택**
    var zombiePrefab = prefabs[Random.Range(0, prefabs.Length)];

    var zombie = Instantiate(zombiePrefab, spawnPoint.position, spawnPoint.rotation);
    var agent = zombie.GetComponent<UnityEngine.AI.NavMeshAgent>();

    if (agent == null)
    {
        Debug.LogError("NavMeshAgent component is missing on the Zombie prefab!");
        Destroy(zombie.gameObject);  // NavMeshAgent가 없으면 좀비 제거
        return;
    }

    // **NavMeshAgent 활성화 및 위치 워프**
    agent.enabled = true;
    if (!agent.Warp(spawnPoint.position))
    {
        Debug.LogError("Failed to place Zombie on NavMesh. Destroying the zombie...");
        Destroy(zombie.gameObject);
        return;
    }

    zombie.Setup(data);  // 좀비 데이터 설정
    zombies.Add(zombie);  // 리스트에 추가

    // 좀비 사망 시 처리
    zombie.onDeath += () => zombies.Remove(zombie);
    zombie.onDeath += () => Destroy(zombie.gameObject, 5f);
    zombie.onDeath += () => gm.AddScore(100);
    zombie.onDeath += () => gm.uiManager.UpdateWaveText(wave, zombies.Count);

    gm.uiManager.UpdateWaveText(wave, zombies.Count);  // UI 업데이트
}


}
