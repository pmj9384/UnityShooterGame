using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class Zombie : LivingEntity
{
    public LayerMask whatIsTarget;  // 타겟 탐색 레이어
    public float findTargetDistance = 10f;  // 탐색 범위

    private NavMeshAgent agent;
    private Animator zombieAnimator;
    private AudioSource audioSource;
    private Coroutine coUpdatePath;
    private LivingEntity targetEntity;

    public ParticleSystem hitEffect;
    public AudioClip hitSound;
    public AudioClip deathSound;
    public float damage = 20f;
    public float timeBetAttack = 0.5f;
    private float lastAttackTime;

    private Renderer ren;

    public void Setup(ZombieData data)
    {
        maxHp = data.hp;
        damage = data.damage;
        agent.speed = data.speed;
        ren.material.color = data.skinColor;
    }

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        zombieAnimator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
        ren = GetComponentInChildren<Renderer>();
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        coUpdatePath = StartCoroutine(UpdatePath());
    }

    protected void OnDisable()
    {
        if (coUpdatePath != null)
        {
            StopCoroutine(coUpdatePath);
            coUpdatePath = null;
        }
    }

    private IEnumerator UpdatePath()
    {
        while (true)
        {
            if (targetEntity == null || targetEntity.IsDead)
                targetEntity = FindTarget();  // 타겟 재탐색

            if (targetEntity != null)
            {
                agent.isStopped = false;
                agent.SetDestination(targetEntity.transform.position);  // 타겟으로 이동
            }
            else
            {
                agent.isStopped = true;  // 타겟 없으면 정지
            }

            yield return new WaitForSeconds(0.25f);
        }
    }

    public LivingEntity FindTarget()
    {
        var cols = Physics.OverlapSphere(transform.position, findTargetDistance, whatIsTarget);
        foreach (var col in cols)
        {
            var livingEntity = col.GetComponent<LivingEntity>();
            if (livingEntity != null && !livingEntity.IsDead)
                return livingEntity;
        }
        return null;
    }

    public override void OnDamage(float damage, Vector3 hitPoint, Vector3 hitNormal)
    {
        base.OnDamage(damage, hitPoint, hitNormal);
        hitEffect.transform.position = hitPoint;
        hitEffect.transform.rotation = Quaternion.LookRotation(hitNormal);
        hitEffect.Play();
        audioSource.PlayOneShot(hitSound);
    }

    protected override void Die()
    {
        base.Die();
        audioSource.PlayOneShot(deathSound);
        zombieAnimator.SetTrigger("Die");

        agent.isStopped = true;
        agent.enabled = false;

        var cols = GetComponents<Collider>();
        foreach (var col in cols)
        {
            col.enabled = false;
        }
    }
}
