using UnityEngine;

public class GameManager : MonoBehaviour
{
    private int score = 0;
    public bool IsGameOver { get; private set; }
    public UiManager uiManager;
    public int CurrentWave { get; private set; } = 1;
    private int remainingZombies;

    public void AddScore(int add)
    {
        if (IsGameOver) return;
        score += add;
        uiManager.UpdateScoreText(score);
    }

    public void DecrementZombieCount()
    {
        remainingZombies--;
        uiManager.UpdateWaveText(CurrentWave, remainingZombies);

        if (remainingZombies <= 0)
        {
            CurrentWave++;
            remainingZombies = 3 * CurrentWave;  // 웨이브마다 좀비 수 증가
            uiManager.UpdateWaveText(CurrentWave, remainingZombies);
        }
    }

    public void OnGameOver()
    {
        IsGameOver = true;
        uiManager.ShowGameOverPanel(true);
    }
}
